//
//  TestPlaygroundApp.swift
//  TestPlayground
//
//  Created by Rizwan Ahmed on 25/10/24.
//

import SwiftUI

@main
struct TestPlaygroundApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
