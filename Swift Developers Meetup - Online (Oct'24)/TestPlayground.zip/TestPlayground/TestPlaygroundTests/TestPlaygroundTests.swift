//
//  TestPlaygroundTests.swift
//  TestPlaygroundTests
//
//  Created by Rizwan Ahmed on 25/10/24.
//

import Testing
@testable import TestPlayground

extension Tag {
    @Tag static var add: Self
    @Tag static var swiftBengaluru: Self

}


@Suite("Swift Bengaluru Demo Test Cases", .tags(.swiftBengaluru))
struct TestPlaygroundTests {

    func add(_ a: Int, _ b: Int) -> Int {
        return a+b
    }
    
    @Test("Test case for add", .disabled())
    func verifyAdd() {
        let result = add(1, 2)
        #expect(result == 3)
    }
    
    func generateNumber() -> Int {
        return Int.random(in: 1..<10)
    }
    
    @Test
    func verifyNumberGeneration() {
        let number = generateNumber()
        #expect(number != 0)
        #expect(number < 10)
    }
    
    
    enum NetworkErrors: Error {
        case invalidToken
        case noResponse
    }
    
    enum GenericErrors: Error {
        case failedToRenderData
    }
    
    
    func throwingFunction() throws {
        throw NetworkErrors.invalidToken
    }
    
    @Test
    func testThrowingFunction() {
        #expect {
            try throwingFunction()
        }throws: { error in
            guard let error = error as? NetworkErrors else {
                return false
            }
            return error == .invalidToken
        }
    }
    
    func returnsANumber() -> Int? {
        return 3
    }
    
    @Test
    func verifyOptionals() throws {
        let number = returnsANumber()
        try #require(number != nil)
    }
    
}

