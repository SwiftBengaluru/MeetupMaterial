//
//  Question.swift
//  Reactor
//
//  Created by Kalyan Dechiraju on 09/09/17.
//  Copyright © 2017 Codelight Studios. All rights reserved.
//

import Foundation

struct Question {
    var description: String
    
}
