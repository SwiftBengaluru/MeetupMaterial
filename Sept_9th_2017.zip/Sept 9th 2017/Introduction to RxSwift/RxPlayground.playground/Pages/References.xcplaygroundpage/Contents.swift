//: [Previous](@previous)

/*:
 ## References
 
 - https://github.com/ReactiveX/RxSwift
 - Schedulers in RxSwift
 - http://reactivex.io/
 - http://rxmarbles.com/
 - https://gist.github.com/staltz/868e7e9bc2a7b8c1f754
 - http://as.ync.io/
 - http://rx-marin.com/
 - https://github.com/vsouza/awesome-ios#reactive-programming
 
 */
