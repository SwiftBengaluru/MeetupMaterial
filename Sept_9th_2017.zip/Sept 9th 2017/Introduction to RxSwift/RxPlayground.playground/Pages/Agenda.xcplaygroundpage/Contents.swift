/*:
 # An introduction to Reactive Programming with RxSwift
 ### Agenda 🎤
 - Who Am I? 🤠
 - What is Reactive Programming? 🤔
 - How to adopt Reactive Programming in iOS? 🙄
 
 
 But before we proceed, let me know about you.
 
 - http://bit.ly/rxswiftblr
 
 */

//: [Next](@next)
