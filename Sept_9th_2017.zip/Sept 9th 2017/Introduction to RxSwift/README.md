# An introduction to reactive programming with RxSwift

### Running the sample

To run the sample, add your own GoogleService-Info.plist file by creating a Firebase project
