//
//  NetworkManager.swift
//  Swift_Bengaluru
//
//  Created by Keshav Kishore on 23/03/24.
//

import Foundation


class NetworkManager {
    
}
