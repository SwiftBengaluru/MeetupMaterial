//
//  ViewController.swift
//  Swift_Bengaluru
//
//  Created by Keshav Kishore on 23/03/24.
//

import UIKit
import OSLog

let logger = Logger(subsystem: "com.codezek.Programatic.Swift-Bengaluru", category: "ViewController")

class ViewController: UIViewController {
    
    
    private lazy var stackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 20
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()
    
    private lazy var firstName: UITextField = {
        let textField = UITextField()
        textField.placeholder = "FirstName"
        return textField
    }()
    
    private lazy var lastName: UITextField = {
        let textField = UITextField()
        textField.placeholder = "LastName"
        return textField
    }()
    
    private lazy var submitButton: UIButton = {
        let button = UIButton()
        button.setTitle("Submit", for: .normal)
        button.addTarget(self, action: #selector(didTabSubmitButon), for: .touchUpInside)
        button.backgroundColor = .systemBlue
        return button
    }()
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        
        view.addSubview(stackView)
        [firstName, lastName, submitButton].forEach( {stackView.addArrangedSubview($0)})
        
        stackView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        stackView.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        
    }
    
    @objc func didTabSubmitButon() {
        logger.debug("Hey, it's printing")
        logger.error("Hey, it's printing")
        logger.info("Hey, it's printing")
          print("Hey, it's printing")
    }
}

#Preview {
   let vc = ViewController()
   return vc
}

